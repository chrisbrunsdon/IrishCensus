#' Main function to extract Irish Census data
#' 
#' Enables data to be extracted from the Irish Census on the basis of theme,
#' table,  field in table or long field name
#' 
#' @param theme Grep pattern to search for census themes - only search if not \code{NA}
#' @param table Grep pattern to search for a census table - only search if not \code{NA} 
#' @param field Grep pattern to search for a census field - only search if not \code{NA}
#' @param longfield Grep pattern to search for a census long field - only search if not \code{NA}
#' @param geogtype Geography type for variable to be returned
#' @details Only one of \code{theme}, \code{table}, \code{field}, \code{longfield} should be specified.  If none are specified,  all variables are returned.
#' \code{geogtype} must be one of:
#' \itemize{
#'   \item{\code{'CTY'}}  Counties
#'   \item{\code{'DC'}}  Dáil Constituencies 2007
#'   \item{\code{'ED'}}  Electoral Divisions
#'   \item{\code{'GA'}}  Gealtacht Areas
#'   \item{\code{'LEA'}}  Local Electoral Areas
#'   \item{\code{'LT'}}  Legal Towns and Cities
#'   \item{\code{'NDC'}}  Dáil Constituencies 2013
#'   \item{\code{'PA'}}  Dublin Parishes
#'   \item{\code{'PR'}}  Provinces
#'   \item{\code{'RA'}}  Regional Authority Areas
#'   \item{\code{'RE'}}  Dioceses
#'   \item{\code{'SA'}}  Small Areas
#'   \item{\code{'ST'}}  Settlements
#' }
#' @return An \code{iecens} object containing the data.  This inherits from the \code{data.frame} object but has some functionality specific to a data chunk extracted from the Irish Census.
#' @examples
#' # Find all fields specifying counts of time people leave home for work or school
#' # with counts per province
#' leave.time <- census.ie(geog='PR',field='T11_2_T[1-8]')
#' leave.time
#' @export
census.ie <- function(theme=NA,table=NA,field=NA,longfield=NA,geogtype="CTY") {
  trimmed <- subset(datasets,GEOGTYPE==geogtype)
  if (!is.na(field)) {
    used <- grep(field,attr(datasets,"variables")$field)
    if (length(used) == 0) stop("No themes match this pattern")
    res <- trimmed[,c(1:3,used+3)]
    class(res) <- c('iecens',class(res))
    return(res)} 
  if (!is.na(longfield)) {
    used <- grep(longfield,attr(datasets,"variables")$longfield)
    if (length(used) == 0) stop("No themes match this pattern")
    res <- trimmed[,c(1:3,used+3)]
    class(res) <- c('iecens',class(res))
    return(res)} 
  if (!is.na(theme)) {
    used <- grep(theme,attr(datasets,"variables")$theme)
    if (length(used) == 0) stop("No themes match this pattern")
    res <- trimmed[,c(1:3,used+3)]
    class(res) <- c('iecens',class(res))
    return(res)
  }
  if (!is.na(table)) {
    used <- grep(table,attr(datasets,"variables")$table)
    if (length(used) == 0) stop("No tables match this pattern")
    res <- trimmed[,c(1:3,used+3)]
    class(res) <- c('iecens',class(res))
    return(res)
  }
  res <- trimmed
  class(res) <- c('iecens',class(res))
  return(res)
}
